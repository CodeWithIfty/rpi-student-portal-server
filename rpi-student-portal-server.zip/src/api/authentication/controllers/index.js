const createAuthCookie = require('./createAuthCookie')
const logout = require('./logout')
module.exports ={
    createAuthCookie,
    logout
}