const controllers = require('./controllers')

module.exports = controllers